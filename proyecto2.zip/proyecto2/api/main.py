# proyecto2/api/main.py

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Importar routers
from controllers import clients, orders, reports, summary

app = FastAPI(
    title="Sistema Logístico de Drones - API",
    description="API para simulación de rutas, pedidos, y generación de reportes.",
    version="2.0"
)

# Permitir CORS para desarrollo local o apps externas
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Cambia esto en producción
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Incluir routers
app.include_router(clients.router, prefix="/clients", tags=["Clients"])
app.include_router(orders.router, prefix="/orders", tags=["Orders"])
app.include_router(reports.router, prefix="/reports", tags=["Reports"])
app.include_router(summary.router, prefix="/info/reports", tags=["Summary"])

@app.get("/")
def root():
    return {"message": "Sistema Logístico de Drones - API v2 funcionando"}
